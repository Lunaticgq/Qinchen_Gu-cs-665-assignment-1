/**
 * Name: Qinchen Gu
 * Course: CS-665 Software Designs & Patterns
 * Date: 02/07/2024
 * File Name: OrderFromMachine.java
 */

package edu.bu.met.cs665.BeverageVendingMachine;

import java.util.Scanner;

public class OrderFromMachine implements Orderable {

    @Override
    public Beverage takeOrder() {
        Scanner scanner = new Scanner(System.in);

        try {
            System.out.println("Please choose your drink:");
            System.out.println("1. Espresso");
            System.out.println("2. Americano");
            System.out.println("3. Latte Macchiato");
            System.out.println("4. Black Tea");
            System.out.println("5. Green Tea");
            System.out.println("6. Yellow Tea");

            int choice = getValidatedChoice(scanner);

            // Validate choice
            if (choice == -1) {
                return null;
            }

            BeverageType selectedDrink = BeverageType.values()[choice - 1];

            System.out.println("Add milk (0-3):");
            int milkUnits = getValidatedUnits(scanner);

            System.out.println("Add sugar (0-3):");
            int sugarUnits = getValidatedUnits(scanner);

            // Validate condiments
            if (milkUnits == -1 || sugarUnits == -1) {
                if(milkUnits == -1) {
                    if(sugarUnits == -1) {
                        System.out.println("Invalid number of units of milk and sugar, please order again!");
                    }else{
                        System.out.println("Invalid number of units of milk, please order again!");
                    }
                }else{
                    System.out.println("Invalid number of units of sugar, please order again!");
                }
                return null;
            }

            return new Beverage(selectedDrink, milkUnits, sugarUnits);
        } finally {

        }
    }

    private int getValidatedChoice(Scanner scanner) {
        int choice = scanner.nextInt();
        if (choice < 1 || choice > 6) {
            System.out.println("Invalid Choice! Please try again!");
            return -1; // Return -1 as an indicator of invalid input
        }
        return choice;
    }

    private int getValidatedUnits(Scanner scanner) {
        int units = scanner.nextInt();
        if (units < 0 || units > 3) {
            System.out.println("Invalid number of units! Please try again!");
            return -1; // Return -1 as an indicator of invalid input
        }
        return units;
    }
}

