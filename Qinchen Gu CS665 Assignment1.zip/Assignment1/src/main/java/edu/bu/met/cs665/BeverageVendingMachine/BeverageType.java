/**
 * Name: Qinchen Gu
 * Course: CS-665 Software Designs & Patterns
 * Date: 02/07/2024
 * File Name: BeverageType.java
 */

package edu.bu.met.cs665.BeverageVendingMachine;

public enum BeverageType {
    ESPRESSO(2.0),
    AMERICAN_COFFEE(2.0),
    LATTE_MACCHIATO(4.0),
    BLACK_TEA(3.0),
    GREEN_TEA(3.0),
    YELLOW_TEA(3.0);

    private final double price;

    BeverageType(double price) {
        this.price = price;
    }

    public double getPrice() {
        return this.price;
    }
}
