/**
 * Name: Qinchen Gu
 * Course: CS-665 Software Designs & Patterns
 * Date: 02/07/2024
 * File Name: Main.java
 */

package edu.bu.met.cs665.BeverageVendingMachine;

public class Main {
    public static void main(String[] args) {
        //use this to help program restart when invalid parameter detected6
       runProgram();
    }

    public static void runProgram() {
        OrderFromMachine orderSummary = new OrderFromMachine();
        Beverage drink = orderSummary.takeOrder();
        if (drink != null) {
            System.out.println("Price: " + drink.calculateTotalPrice());
            System.out.println("Processing: " + drink.getDescription() );
            System.out.println("Enjoy It!");
        }else if (drink == null){
            System.out.println();
            runProgram();
        }
    }
}
