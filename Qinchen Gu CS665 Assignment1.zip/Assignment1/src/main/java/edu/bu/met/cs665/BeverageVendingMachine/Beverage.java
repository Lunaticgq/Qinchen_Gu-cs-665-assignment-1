/**
 * Name: Qinchen Gu
 * Course: CS-665 Software Designs & Patterns
 * Date: 02/07/2024
 * File Name: Beverage.java
 */

package edu.bu.met.cs665.BeverageVendingMachine;

public class Beverage extends Condiment {
    private BeverageType type;

    public Beverage(BeverageType type, int milkUnits, int sugarUnits) {
        super(milkUnits, sugarUnits);
        this.type = type;
    }

    @Override
    public String getDescription() {
        return type.toString() + " with " + milkUnits + " milk units and " + sugarUnits + " sugar units";
    }

    @Override
    public double calculateTotalPrice() {
        return type.getPrice() + (milkUnits + sugarUnits) * CONDIMENT_PRICE;
    }
}
