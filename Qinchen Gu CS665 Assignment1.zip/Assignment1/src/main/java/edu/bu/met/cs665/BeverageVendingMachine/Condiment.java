/**
 * Name: Qinchen Gu
 * Course: CS-665 Software Designs & Patterns
 * Date: 02/07/2024
 * File Name: Condiment.java
 */

package edu.bu.met.cs665.BeverageVendingMachine;

public abstract class Condiment {
    protected int milkUnits;
    protected int sugarUnits;
    protected static final double CONDIMENT_PRICE = 0.5;

    public Condiment(int milkUnits, int sugarUnits) {
        this.milkUnits = milkUnits;
        this.sugarUnits = sugarUnits;
    }

    public abstract String getDescription();
    public abstract double calculateTotalPrice();
}
