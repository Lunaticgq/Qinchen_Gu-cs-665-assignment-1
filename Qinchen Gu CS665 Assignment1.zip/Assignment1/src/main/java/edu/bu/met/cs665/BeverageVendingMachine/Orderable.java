/**
 * Name: Qinchen Gu
 * Course: CS-665 Software Designs & Patterns
 * Date: 02/07/2024
 * File Name: Orderable.java
 */

package edu.bu.met.cs665.BeverageVendingMachine;

public interface Orderable {
    Beverage takeOrder();
}
