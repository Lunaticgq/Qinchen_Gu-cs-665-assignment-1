/**
 * Name: Qinchen Gu
 * Course: CS-665 Software Designs & Patterns
 * Date: 02/07/2024
 * File Name: DrinkTest.java
 */

package edu.bu.met.cs665;

import static org.junit.Assert.assertEquals;
import org.junit.Test;
import edu.bu.met.cs665.BeverageVendingMachine.OrderFromMachine;
import edu.bu.met.cs665.BeverageVendingMachine.Condiment;
import edu.bu.met.cs665.BeverageVendingMachine.Beverage;
import edu.bu.met.cs665.BeverageVendingMachine.BeverageType;

public class BeverageTest {

    @Test
    public void testEspressoDescription() {
        Beverage espresso = new Beverage(BeverageType.ESPRESSO, 1, 1);
        String description = espresso.getDescription();
        assertEquals("ESPRESSO with 1 milk units and 1 sugar units", description);
    }

    @Test
    public void testEspressoPrice() {
        Beverage espresso = new Beverage(BeverageType.ESPRESSO, 1, 1);
        double price = espresso.calculateTotalPrice();
        assertEquals(3.0, price, 0.0);
    }

    @Test
    public void testLatteMacchiatoPriceWithNoCondiments() {
        Beverage latte = new Beverage(BeverageType.LATTE_MACCHIATO, 0, 0);
        double price = latte.calculateTotalPrice();
        assertEquals(2.0, price, 0.0);
    }

    @Test
    public void testLatteMacchiatoPriceWithMaxCondiments() {
        Beverage latte = new Beverage(BeverageType.LATTE_MACCHIATO, 3, 3);
        double price = latte.calculateTotalPrice();
        assertEquals(5.0, price, 0.0);
    }

}
